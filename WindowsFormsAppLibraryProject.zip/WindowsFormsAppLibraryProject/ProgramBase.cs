﻿namespace WindowsFormsAppLibraryProject
{
	internal static class ProgramBase
	{
	}
}