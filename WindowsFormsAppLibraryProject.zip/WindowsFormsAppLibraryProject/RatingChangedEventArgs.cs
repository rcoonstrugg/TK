﻿internal class RatingChangedEventArgs
{
	private int currentRating;

	public RatingChangedEventArgs(int currentRating)
	{
		this.currentRating = currentRating;
	}
}